import type { FinalResult } from "./utils";
import React from "react";
import { BarChart } from "./bar-chart";
import { ChartActions } from "./chart-actions";
import { PieChart } from "./pie-chart";

interface ChartProps {
  results: FinalResult | null;
  sortByTotal?: boolean;
  title?: boolean;
  pie?: boolean;
  showEmptyOptions?: boolean;
}

export const Chart: React.FC<ChartProps> = ({
  results,
  sortByTotal = true,
  title = false,
  pie = false,
  showEmptyOptions = true
}) => {
  if (!results)
    return null;

  const ChartComponent = pie ? PieChart : BarChart;

  return (
    <div className="bg-muted/45 border-2 border-border relative font-mono">
      <div className="p-3">
        {title && (
          <p className="text-md py-4 font-semibold mb-4">{results.label}</p>
        )}
        <ChartComponent
          results={results}
          sortByTotal={sortByTotal}
          showEmptyOptions={showEmptyOptions}
        />
        {results?.otherOptions.length > 0 && (
          <details className="mt-4">
            <summary className="text-sm font-semibold">
              Others (
              {results?.otherOptions.length}
              )
              <span className="text-xs text-muted-foreground">
                submitted by participants
              </span>
            </summary>
            <div className="overflow-scroll max-h-[400px]">
              <table className="w-full border-collapse">
                <tbody>
                  {results?.otherOptions.map((option, index) => (
                    <tr
                      key={option}
                      className={index % 2 === 0 ? "bg-muted/30" : ""}
                    >
                      <td className="py-1 px-2 border-b border-border">
                        {option}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </details>
        )}
      </div>
      <ChartActions results={results} />
    </div>
  );
};
