import { evaluateCondition, getExclusiveChoiceIndices, getVisibleChoiceIndices } from "@/lib/conditions";
import { Question } from "./question";
import { Steps } from "./steps";
import { SurveyMachineContext } from "./survey-context";
import { SurveyActions } from "./survey-controls";

const QUESTION_CONTAINER_MIN_HEIGHT = "300px";

export function SurveyForm() {
  const actorRef = SurveyMachineContext.useActorRef();

  // Select all needed state
  const context = SurveyMachineContext.useSelector(state => state.context);

  // Compute derived state
  const currentSection = context.sections[context.currentSectionIdx];
  const currentQuestion = currentSection?.questions[context.currentQuestionIdx];

  const questionId = `${currentSection.label}-q-${context.currentQuestionIdx}`;

  // Numbered among the questions this respondent sees, so skipped ones leave no gaps
  const questionNumber = currentSection.questions
    .slice(0, context.currentQuestionIdx)
    .filter(question => evaluateCondition(question.showIf, context.answers))
    .length + 1;

  const handleAnswerChange = (value: number | number[] | null | string) => {
    actorRef.send({
      type: "ANSWER_CHANGE",
      questionId,
      value
    });
  };

  const handleOthersChange = (value: string) => {
    actorRef.send({
      type: "ANSWER_CHANGE",
      questionId: `${questionId}-others`,
      value
    });
  };

  if (!currentSection || !currentQuestion) {
    return null;
  }

  return (
    <div className="min-h-screen pt-10">
      <Steps />
      <main className="flex flex-1 justify-center items-center">
        <div
          id={currentSection.label}
          className="md:w-[700px] w-full px-4 md:px-0"
        >
          <div
            className="mb-10 min-h-screen transition-all duration-1000"
            style={{
              minHeight: `min(${QUESTION_CONTAINER_MIN_HEIGHT}, 100vh)`
            }}
          >
            <Question
              selected={true}
              question={currentQuestion}
              index={context.currentQuestionIdx}
              number={questionNumber}
              key={questionId}
              sectionId={currentSection.label}
              value={
                context.answers[questionId] as
                | number
                | number[]
                | null
                | undefined
              }
              othersValue={
                context.answers[`${questionId}-others`] as string | undefined
              }
              visibleChoices={getVisibleChoiceIndices(currentQuestion, context.answers)}
              exclusiveChoices={getExclusiveChoiceIndices(currentQuestion)}
              onAnswerChange={handleAnswerChange}
              onOthersChange={handleOthersChange}
            />
          </div>

          <SurveyActions />
        </div>
      </main>
    </div>
  );
}
